package org.fxmisc.richtext;

import javafx.scene.shape.Path;

/**
 * A path which describes a background shape in the Scene graph.
 */
public class BackgroundPath extends Path {
}
